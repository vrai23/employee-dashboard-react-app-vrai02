import React from 'react' ;

const Title = (props) => {
    return (
        <h1>Name: {props.name} <br />
        Last Name: {props.last}</h1>
    )
}

export default Title;
